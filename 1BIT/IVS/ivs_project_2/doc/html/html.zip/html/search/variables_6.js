var searchData=
[
  ['root_91',['root',['../calculator_8py.html#a2636da1e422b2c934583c500ed50fbd6',1,'calculator']]],
  ['row_92',['row',['../calculator_8py.html#abfab3025898b83fbaffafee524fc34be',1,'calculator']]]
];
