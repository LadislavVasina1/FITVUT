Prostredi
---------

Ubuntu 64bit

Autori
------

4 Exceptions
- xvasin11 Ladislav Vašina
- xvagne10 Dominik Vágner
- xpoliv06 Tomáš Polívka 
- xhajek51 Vojtěch Hájek

Licence
-------

Tento program je poskytovan pod GNU GPL v.3
© 2021 4 Exceptions