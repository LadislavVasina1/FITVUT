var searchData=
[
  ['remove_5flast_67',['remove_last',['../calculator_8py.html#a9e2c3a063928883e256a09c6367c0e8e',1,'calculator']]],
  ['root_68',['root',['../math__functions_8py.html#a50ac5f83e987cd3bd8cb7b72d27c15a8',1,'math_functions']]]
];
