var searchData=
[
  ['remove_5flast_28',['remove_last',['../calculator_8py.html#a9e2c3a063928883e256a09c6367c0e8e',1,'calculator']]],
  ['root_29',['root',['../calculator_8py.html#a2636da1e422b2c934583c500ed50fbd6',1,'calculator.root()'],['../math__functions_8py.html#a50ac5f83e987cd3bd8cb7b72d27c15a8',1,'math_functions.root()']]],
  ['row_30',['row',['../calculator_8py.html#abfab3025898b83fbaffafee524fc34be',1,'calculator']]]
];
