var searchData=
[
  ['keyboard_5fentry_18',['keyboard_entry',['../calculator_8py.html#a52f66128b3fd0e079400905b8ebe14b3',1,'calculator']]]
];
