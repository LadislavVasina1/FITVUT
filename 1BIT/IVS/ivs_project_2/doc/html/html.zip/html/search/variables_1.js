var searchData=
[
  ['background_84',['background',['../calculator_8py.html#ab780a84755be2e504256ffb025c83c53',1,'calculator']]],
  ['btn_5fstyle_85',['btn_style',['../calculator_8py.html#a3a0abe4cf00e9a659d1b79cb5d367e32',1,'calculator']]]
];
