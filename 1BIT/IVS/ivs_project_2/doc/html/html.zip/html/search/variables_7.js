var searchData=
[
  ['weight_93',['weight',['../calculator_8py.html#a72acca4fe8167b2174ccbc31bbd15009',1,'calculator']]]
];
