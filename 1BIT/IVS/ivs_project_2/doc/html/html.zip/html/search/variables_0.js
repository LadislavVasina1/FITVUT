var searchData=
[
  ['about_83',['about',['../calculator_8py.html#a72e6babf70db40e15f7d533da8a88960',1,'calculator']]]
];
