var searchData=
[
  ['scientific_31',['scientific',['../math__functions_8py.html#a78e7dcda644f50f1d02ba4b148edba0d',1,'math_functions']]],
  ['show_5fabout_32',['show_about',['../calculator_8py.html#aed334fa5b20f7626b02ba1edd2bc4131',1,'calculator']]],
  ['show_5fhelp_33',['show_help',['../calculator_8py.html#a06d1c30c7c62e1dc3408e093eb2dae9f',1,'calculator']]],
  ['subtract_34',['subtract',['../math__functions_8py.html#a0fb1f491b179b15e62cf6f49bd2557e6',1,'math_functions']]]
];
